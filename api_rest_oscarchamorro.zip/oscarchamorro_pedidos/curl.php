<?php 
require_once 'database/conexion.php';
$result = $mysqli->query("SELECT id FROM users WHERE email = '".$_POST["email"]."' ");
$row = mysqli_fetch_array($result);
if($row['id'] == NULL){
	$curl = curl_init();
	curl_setopt_array($curl, array(
		CURLOPT_PORT => "3000",
		CURLOPT_URL => "http://localhost:3000/users",
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 30,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "POST",
		CURLOPT_POSTFIELDS => "{
			\n\t\"nombres\":\"".$_POST["nombres"]."\",
			\n\t\"apellidos\":\"".$_POST["apellidos"]."\",
			\n\t\"email\":\"".$_POST["email"]."\",
			\n\t\"telefono\":\"".$_POST["telefono"]."\",
			\n\t\"direccion\":\"".$_POST["direccion"]."\",
			\n\t\"fechaentrega\":\"".$_POST["fechaentrega"]."\",
			\n\t\"franjahoraria\":\"".$_POST["franjahoraria"]."\"
			\n}",
		CURLOPT_HTTPHEADER => array(
		"content-type: application/json"
		),
	));
	$response = curl_exec($curl);
	$err = curl_error($curl);
	curl_close($curl);
	if($err){
		exit;
		echo "cURL Error #:" . $err;
	} 
	else{
		echo $response;
	}
}
else{
	echo '<div class="row my-3">
			<div class="col-12 col-sm-12 col-md-12 text-center alert alert-danger">
				<h4>El email ingresado ya se ecuenta almacenado en la base de datos!</h4>
			</div>
		</div>
		';
}
?>