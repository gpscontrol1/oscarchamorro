const user = require('../models/users');
module.exports = function(app){
	app.get('/users', (req, res) =>{
		user.getUsers((err, data) =>{
			res.json(data);
		});
	});
	app.post('/users', (req, res)=>{
		var userData ={
			nombres: req.body.nombres,
			apellidos: req.body.apellidos,
			email: req.body.email,
			telefono: req.body.telefono,
			direccion: req.body.direccion,
			fechaentrega: req.body.fechaentrega,
			franjahoraria: req.body.franjahoraria
		};
		
		console.log(userData);
		
		user.insertUser(userData, (err, data) =>{ 
			if(data){
				user.consultUsers(userData, (err, data) =>{ 
					res.json(data);
				});
			}
			else{
				res.status(500).json({
					success: false,
					msg: err
				});
			}
		});
		
		
	});
}