const mysql = require('mysql');
connection = mysql.createConnection({
	host: 'localhost',
	user:'root',
	password:'',
	database:'pedidos'
});
let userModel = {};
userModel.getUsers = (callback) =>{
	if(connection){
		connection.query(
			'SELECT * FROM users ORDER BY id',
			(err, rows) =>{
				if(err){
					throw err;
				}
				else{
					callback(null, rows);
				}
			}
		);
	}
};
userModel.insertUser = (userData, callback) =>{
	if(connection){
		
		var userData1 = {
			nombres: userData.nombres,
			apellidos: userData.apellidos,
			email: userData.email,
			telefono: userData.telefono
		}
		
		connection.query(
			'INSERT INTO users SET ?', userData1,
			(err, res) =>{
				if(err){
					throw err;
				}
				else{
					callback(null, {
						nombres: res.nombres,
						apellidos: res.apellidos,
						email: res.email,
						telefono: res.telefono
					});
				}
			}
		);
	}
}
userModel.consultUsers = (userData, callback) =>{
	if(connection){
		console.log(userData);
		connection.query(
			'SELECT id FROM users WHERE email = "'+userData.email+'"',
			(err, rows) =>{
				if(err){
					throw err;
				}
				else{
					connection.query(
						'SELECT id FROM driver WHERE alta = 0 ORDER BY RAND() LIMIT 1',
						(err, rows) =>{
							if(err){
								throw err;
							}
							else{
								var driver = rows[0].id;
								connection.query(
									'INSERT INTO pedidos(userid, direccion, fechaentrega, franjahoraria, driverid) VALUES('+rows[0].id+', "'+userData.direccion+'", "'+userData.fechaentrega+'", "'+userData.franjahoraria+'", "'+driver+'")', 
									(err, res) =>{
										if(err){
											throw err;
										}
										else{
											callback(null, {
												userid: rows,
												direccion: userData.direccion
											});
										}
									}
								);
							}
						}
					);
					
					
				}
			}
		);
	}
};
module.exports = userModel;