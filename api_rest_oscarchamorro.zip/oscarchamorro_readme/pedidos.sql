-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 07-01-2020 a las 06:38:07
-- Versión del servidor: 10.1.38-MariaDB
-- Versión de PHP: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `pedidos`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `driver`
--

CREATE TABLE `driver` (
  `id` int(11) NOT NULL,
  `nombres` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `apellidos` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `alta` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `driver`
--

INSERT INTO `driver` (`id`, `nombres`, `apellidos`, `alta`) VALUES
(1, 'juan', 'perez', 0),
(2, 'alex', 'garcia', 1),
(3, 'pepe', 'grillo', 0),
(4, 'jose', 'martinez', 0),
(5, 'raul', 'zambrano', 0),
(6, 'carolina', 'velasquez', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `direccion` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `fechasolicitud` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fechaentrega` date NOT NULL,
  `franjahoraria` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `driverid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `pedidos`
--

INSERT INTO `pedidos` (`id`, `userid`, `direccion`, `fechasolicitud`, `fechaentrega`, `franjahoraria`, `driverid`) VALUES
(1, 4, 'Calle falsa No. 123', '2020-01-06 20:08:59', '2020-01-07', '8:00-16:00', 4),
(2, 4, 'Calle falsa No. 125', '2020-01-06 20:08:59', '2020-01-07', '8:00-16:00', 4),
(3, 4, 'Calle falsa No. 125', '2020-01-06 20:08:59', '2020-01-07', '8:00-16:00', 1),
(4, 4, 'Calle falsa No. 125', '2020-01-06 20:08:59', '2020-01-07', '8:00-16:00', 1),
(5, 4, 'Calle falsa No. 126', '2020-01-06 20:09:59', '2020-01-07', '8:00-14:00', 4),
(6, 4, 'Calle falsa No. 127', '2020-01-06 20:10:59', '2020-01-07', '8:00-13:00', 3),
(7, 3, 'Calle falsa No. 123', '2020-01-07 06:27:35', '2020-01-08', '8:00-16:00', 3),
(8, 4, 'calle falsa 123', '2020-01-07 06:33:32', '2020-01-08', '8:00-16:00', 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nombres` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `apellidos` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `creado` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `nombres`, `apellidos`, `email`, `telefono`, `creado`) VALUES
(1, 'oscar', 'chamorro', 'oscar.chamorroz@gmail.com', '0513777777', '2020-01-06 20:08:59'),
(2, 'oscar', 'chamorro', 'oscar.chamorroz1@gmail.com', '0513777777', '2020-01-07 06:27:35'),
(3, 'oscar', 'chamorro', 'oscar.chamorroz2@gmail.com', '0573888888', '2020-01-07 06:33:32');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `driver`
--
ALTER TABLE `driver`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `driver`
--
ALTER TABLE `driver`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
