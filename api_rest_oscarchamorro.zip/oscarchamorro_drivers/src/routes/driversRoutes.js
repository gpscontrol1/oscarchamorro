module.exports = function(app){
	app.get('/drivers', (req, res) =>{
		const driver = require('../models/drivers');
		driver.getDriver((err, data) =>{
			for(i=0;i<data.length;i++){
				if((data[i].driverid == req.body.id) == true && JSON.stringify(data[i].fechaentrega).substr(1,10) === req.body.fechaentrega){
					console.log(JSON.stringify(data[i]));
					res.json(JSON.stringify(data[i]));
				}
			}
		});
	});
}