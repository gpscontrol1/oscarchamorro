var express = require('express');
var morgan = require('morgan');
var bodyParser = require('body-parser');
var app = express();
app.set('port', process.env.PORT || 3000);
app.use(morgan('dev'));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
require('./routes/driversRoutes')(app);
app.listen(app.get('port'), () => {
	console.log('server on port 3000');
});