const user = require('../models/users');
module.exports = function(app){
	app.get('/users', (req, res) =>{
		user.getUsers((err, data) =>{
			res.json(data);
		});
	});
	app.post('/users', (req, res)=>{
		var userData ={
			nombres: req.query.nombres,
			apellidos: req.query.apellidos,
			email: req.query.email,
			telefono: req.query.telefono,
			direccion: req.query.direccion,
			fechaentrega: req.query.fechaentrega,
			franjahoraria: req.query.franjahoraria
		};
		console.log(userData);
		user.insertUser(userData, (err, data) =>{ 
			if(data){
				user.consultUsers(userData, (err, data) =>{ 
					res.json(data);
				});
			}
			else{
				res.status(500).json({
					success: false,
					msg: err
				});
			}
		});
	});
}