SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


CREATE TABLE `driver` (
  `id` int(11) NOT NULL,
  `nombres` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `apellidos` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `alta` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `driver` (`id`, `nombres`, `apellidos`, `alta`) VALUES
(1, 'juan', 'perez', 0),
(2, 'alex', 'garcia', 1),
(3, 'pepe', 'grillo', 0),
(4, 'jose', 'martinez', 0),
(5, 'raul', 'zambrano', 0),
(6, 'carolina', 'velasquez', 0);

CREATE TABLE `pedidos` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `direccion` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `fechasolicitud` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fechaentrega` date NOT NULL,
  `franjahoraria` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `driverid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `pedidos` (`id`, `userid`, `direccion`, `fechasolicitud`, `fechaentrega`, `franjahoraria`, `driverid`) VALUES
(1, 1, 'calle falsa 123', '2020-01-09 14:03:02', '2020-01-11', '8:00-16:00', 1),
(2, 1, 'calle falsa 123', '2020-01-09 14:03:02', '2020-01-11', '8:00-16:00', 1),
(3, 1, 'calle falsa 123', '2020-01-09 15:03:02', '2020-01-12', '9:00-16:00', 1),
(4, 1, 'calle falsa 123', '2020-01-09 09:03:02', '2020-01-10', '10:00-16:00', 1),
(5, 1, 'calle falsa 123', '2020-01-09 11:03:02', '2020-01-10', '11:00-16:00', 1),
(6, 2, 'calle falsa 567', '2020-01-09 14:28:18', '2020-01-10', '8:00-16:00', 2);

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nombres` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `apellidos` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `creado` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `users` (`id`, `nombres`, `apellidos`, `email`, `telefono`, `creado`) VALUES
(1, 'pepe', 'grillo', 'pepe@gmail.com', '0313777777', '2020-01-09 14:03:01'),
(3, 'pedro', 'gomez', 'pedro@pedro.com', '0513888888', '2020-01-09 14:27:45');


ALTER TABLE `driver`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);


ALTER TABLE `driver`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

ALTER TABLE `pedidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
