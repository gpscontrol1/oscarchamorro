
module.exports = function(app){
	
	app.get('/drivers', (req, res) =>{
		
		const mysql = require('mysql');
		connection = mysql.createConnection({
			host: 'localhost',
			user:'root',
			password:'',
			database:'pedidos'
		});
		let driverModel = {};
		
		driverModel.getDrivers = (callback) =>{
			if(connection){
				
				console.log('SELECT * FROM pedidos WHERE driverid = '+req.body.id+' AND fechaentrega = "'+req.body.fechaentrega.substring(1,10)+'" ORDER BY id');
				
				connection.query(
					'SELECT * FROM pedidos WHERE driverid = '+req.body.id+' AND fechaentrega = "'+req.body.fechaentrega.substring(0,10)+'" ORDER BY id',
					(err, rows) =>{
						if(err){
							throw err;
						}
						else{
							callback(null, rows);
						}
					}
				);
			}
		};
		
		
		
		
		driverModel.getDrivers((err, data) =>{
			
			
			// console.log(req);
			
			res.json(data);
		});
	});
}